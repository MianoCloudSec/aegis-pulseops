import subprocess
import time
import signal
import os
import psutil
import logging
from aegis.config import NODE_ID, AUTO_RECOVERY_ENABLED, RECOVERY_COOLDOWN

logger = logging.getLogger("aegis.recovery")


class RecoveryEngine:
    def __init__(self, chaos_engine=None):
        self._chaos = chaos_engine          # reference to ChaosEngine for stopping threads
        self._last_recovery = {}            # metric_level -> last recovery timestamp

    def _cooldown_ok(self, key: str) -> bool:
        return (time.time() - self._last_recovery.get(key, 0)) > RECOVERY_COOLDOWN

    def _set_recovered(self, key: str):
        self._last_recovery[key] = time.time()

    def respond(self, anomaly: dict) -> dict | None:
        if not AUTO_RECOVERY_ENABLED:
            logger.info(f"[Recovery] Auto-recovery disabled — skipping {anomaly['metric']}")
            return None

        metric = anomaly["metric"]
        level  = anomaly["level"]
        value  = anomaly["value"]

        if not self._cooldown_ok(f"{metric}_{level}"):
            logger.info(f"[Recovery] Cooldown active for {metric} — skipping")
            return None

        logger.info(f"[Recovery] Responding to {level} {metric} at {value:.1f}%")

        if metric == "cpu":
            result = self._recover_cpu(value, level)
        elif metric == "memory":
            result = self._recover_memory(value, level)
        elif metric == "disk":
            result = self._recover_disk(value, level)
        else:
            return None

        if result:
            self._set_recovered(f"{metric}_{level}")
        return result

    # ── CPU ───────────────────────────────────────────────────────────────
    def _recover_cpu(self, value: float, level: str) -> dict:
        start = time.time()
        if level == "critical":
            # Step 1: stop chaos engine — terminates stress-ng immediately
            if self._chaos and self._chaos.is_active("cpu_spike"):
                logger.info("[Recovery] Stopping cpu_spike via chaos engine")
                self._chaos.stop("cpu_spike")
            # Step 2: kill any remaining high-CPU processes (process group)
            action, target, output, success = self._kill_top_cpu_process()
        else:
            action, target, output, success = (
                "log_alert", "system",
                f"CPU at {value:.1f}% — monitoring, no action at warning level", True
            )
        return {"action_type": action, "target": target, "success": success,
                "duration_ms": (time.time()-start)*1000, "output": output}

    def _kill_top_cpu_process(self):
        SAFE = {"systemd","init","kernel","kthreadd","python3","python",
                "uvicorn","sshd","bash","sh","aegis"}
        try:
            top_proc, top_cpu = None, 0
            for p in psutil.process_iter(["pid","name","cpu_percent"]):
                try:
                    info = p.info
                    if info["name"] in SAFE:
                        continue
                    if info["cpu_percent"] > top_cpu:
                        top_cpu, top_proc = info["cpu_percent"], p
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass

            if top_proc and top_cpu > 10:
                name, pid = top_proc.name(), top_proc.pid
                try:
                    # Kill entire process GROUP — takes all stress-ng workers at once
                    os.killpg(os.getpgid(pid), signal.SIGKILL)
                    output = f"Killed process group of {name}[{pid}] — {top_cpu:.1f}% CPU"
                except Exception:
                    top_proc.kill()
                    output = f"Killed {name}[{pid}] — {top_cpu:.1f}% CPU"
                return "kill_process", f"{name}[{pid}]", output, True
            else:
                return "log_alert", "none", "No killable high-CPU process found", False
        except Exception as e:
            return "kill_process", "unknown", f"Error: {e}", False

    # ── MEMORY ───────────────────────────────────────────────────────────
    def _recover_memory(self, value: float, level: str) -> dict:
        start = time.time()
        if level == "critical":
            steps = []
            # Step 1: stop chaos thread — releases bytearray allocation immediately
            if self._chaos and self._chaos.is_active("memory_leak"):
                logger.info("[Recovery] Stopping memory_leak thread to free allocation")
                self._chaos.stop("memory_leak")
                time.sleep(0.5)  # give Python GC 500ms to reclaim
                steps.append("chaos thread stopped + allocation freed")
            # Step 2: drop page cache
            _, _, cache_out, _ = self._drop_caches()
            steps.append(cache_out)
            return {"action_type": "drop_caches", "target": "memory", "success": True,
                    "duration_ms": (time.time()-start)*1000, "output": " | ".join(steps)}
        else:
            return {"action_type": "log_alert", "target": "system", "success": True,
                    "duration_ms": (time.time()-start)*1000,
                    "output": f"Memory at {value:.1f}% — monitoring"}

    def _drop_caches(self):
        try:
            r = subprocess.run(
                ["sh", "-c", "sync && echo 3 > /proc/sys/vm/drop_caches"],
                capture_output=True, text=True, timeout=5
            )
            if r.returncode == 0:
                return "drop_caches", "/proc/sys/vm/drop_caches", "Page cache dropped", True
            return "drop_caches", "/proc/sys/vm/drop_caches", f"Failed: {r.stderr}", False
        except Exception as e:
            return "drop_caches", "system", f"Error: {e}", False

    # ── DISK ──────────────────────────────────────────────────────────────
    def _recover_disk(self, value: float, level: str) -> dict:
        start = time.time()
        steps = []
        # Step 1: stop disk fill thread — prevents re-filling during cleanup
        if self._chaos and self._chaos.is_active("disk_fill"):
            logger.info("[Recovery] Stopping disk_fill thread")
            self._chaos.stop("disk_fill")
            time.sleep(0.3)
            steps.append("disk fill stopped")
        # Step 2: vacuum journal
        _, _, log_out, log_ok = self._clean_logs()
        steps.append(log_out)
        return {"action_type": "clean_logs", "target": "/var/log", "success": log_ok,
                "duration_ms": (time.time()-start)*1000, "output": " | ".join(steps)}

    def _clean_logs(self):
        try:
            r = subprocess.run(
                ["journalctl", "--vacuum-size=100M"],
                capture_output=True, text=True, timeout=15
            )
            freed = r.stderr or r.stdout or "Done"
            return "clean_logs", "/var/log", freed.strip(), r.returncode == 0
        except Exception as e:
            return "clean_logs", "/var/log", f"Error: {e}", False

    # ── SERVICE RESTART ───────────────────────────────────────────────────
    def restart_service(self, service_name: str) -> dict:
        start = time.time()
        try:
            r = subprocess.run(
                ["systemctl", "restart", service_name],
                capture_output=True, text=True, timeout=30
            )
            return {"action_type": "restart_service", "target": service_name,
                    "success": r.returncode == 0,
                    "duration_ms": (time.time()-start)*1000,
                    "output": (r.stdout or r.stderr or "Done").strip()}
        except Exception as e:
            return {"action_type": "restart_service", "target": service_name,
                    "success": False, "duration_ms": (time.time()-start)*1000, "output": str(e)}
