from collections import deque
import time
from aegis.config import (
    CPU_WARN_THRESHOLD, CPU_CRIT_THRESHOLD,
    MEM_WARN_THRESHOLD, MEM_CRIT_THRESHOLD,
    DISK_WARN_THRESHOLD, DISK_CRIT_THRESHOLD,
    TREND_WINDOW_MINUTES, TREND_RATE_THRESHOLD,
    METRICS_INTERVAL,
)

# Rolling window: keep last N readings for trend analysis
WINDOW_SIZE = int((TREND_WINDOW_MINUTES * 60) / METRICS_INTERVAL)

class AnomalyDetector:
    def __init__(self):
        self.cpu_history  = deque(maxlen=WINDOW_SIZE)
        self.mem_history  = deque(maxlen=WINDOW_SIZE)
        self.disk_history = deque(maxlen=WINDOW_SIZE)
        self._last_alerts = {}  # metric -> last alert time (cooldown)
        self.ALERT_COOLDOWN = 10  # seconds — fast re-alert during chaos

    def _cooldown_ok(self, key: str) -> bool:
        last = self._last_alerts.get(key, 0)
        return (time.time() - last) > self.ALERT_COOLDOWN

    def _set_alerted(self, key: str):
        self._last_alerts[key] = time.time()

    def _trend_rate(self, history: deque) -> float:
        """Calculate rate of change per minute over the window."""
        if len(history) < 4:
            return 0.0
        vals = list(history)
        # Linear regression slope
        n = len(vals)
        x_mean = (n - 1) / 2
        y_mean = sum(vals) / n
        numerator   = sum((i - x_mean) * (v - y_mean) for i, v in enumerate(vals))
        denominator = sum((i - x_mean) ** 2 for i in range(n))
        if denominator == 0:
            return 0.0
        slope_per_sample = numerator / denominator
        # Convert to per minute
        samples_per_min = 60 / METRICS_INTERVAL
        return slope_per_sample * samples_per_min

    def analyze(self, metrics: dict) -> list:
        """
        Analyze metrics and return list of anomaly dicts.
        Each anomaly: {level, metric, value, threshold, message, trend_rate}
        """
        cpu  = metrics["cpu_percent"]
        mem  = metrics["mem_percent"]
        disk = metrics["disk_percent"]

        self.cpu_history.append(cpu)
        self.mem_history.append(mem)
        self.disk_history.append(disk)

        anomalies = []

        # ── CPU ──────────────────────────────────────────────────────────
        cpu_trend = self._trend_rate(self.cpu_history)

        if cpu >= CPU_CRIT_THRESHOLD and self._cooldown_ok("cpu_crit"):
            anomalies.append({
                "level": "critical", "metric": "cpu",
                "value": cpu, "threshold": CPU_CRIT_THRESHOLD,
                "trend_rate": cpu_trend,
                "message": f"CPU critical: {cpu:.1f}% (threshold {CPU_CRIT_THRESHOLD}%)"
            })
            self._set_alerted("cpu_crit")

        elif cpu >= CPU_WARN_THRESHOLD and self._cooldown_ok("cpu_warn"):
            anomalies.append({
                "level": "warning", "metric": "cpu",
                "value": cpu, "threshold": CPU_WARN_THRESHOLD,
                "trend_rate": cpu_trend,
                "message": f"CPU elevated: {cpu:.1f}% (threshold {CPU_WARN_THRESHOLD}%)"
            })
            self._set_alerted("cpu_warn")

        elif cpu_trend >= TREND_RATE_THRESHOLD and self._cooldown_ok("cpu_trend"):
            anomalies.append({
                "level": "warning", "metric": "cpu",
                "value": cpu, "threshold": CPU_WARN_THRESHOLD,
                "trend_rate": cpu_trend,
                "message": f"CPU trending up: +{cpu_trend:.1f}%/min — predictive alert"
            })
            self._set_alerted("cpu_trend")

        # ── Memory ───────────────────────────────────────────────────────
        mem_trend = self._trend_rate(self.mem_history)

        if mem >= MEM_CRIT_THRESHOLD and self._cooldown_ok("mem_crit"):
            anomalies.append({
                "level": "critical", "metric": "memory",
                "value": mem, "threshold": MEM_CRIT_THRESHOLD,
                "trend_rate": mem_trend,
                "message": f"Memory critical: {mem:.1f}% (threshold {MEM_CRIT_THRESHOLD}%)"
            })
            self._set_alerted("mem_crit")

        elif mem >= MEM_WARN_THRESHOLD and self._cooldown_ok("mem_warn"):
            anomalies.append({
                "level": "warning", "metric": "memory",
                "value": mem, "threshold": MEM_WARN_THRESHOLD,
                "trend_rate": mem_trend,
                "message": f"Memory elevated: {mem:.1f}% (threshold {MEM_WARN_THRESHOLD}%)"
            })
            self._set_alerted("mem_warn")

        elif mem_trend >= TREND_RATE_THRESHOLD and self._cooldown_ok("mem_trend"):
            anomalies.append({
                "level": "warning", "metric": "memory",
                "value": mem, "threshold": MEM_WARN_THRESHOLD,
                "trend_rate": mem_trend,
                "message": f"Memory trending up: +{mem_trend:.1f}%/min — predictive alert"
            })
            self._set_alerted("mem_trend")

        # ── Disk ─────────────────────────────────────────────────────────
        if disk >= DISK_CRIT_THRESHOLD and self._cooldown_ok("disk_crit"):
            anomalies.append({
                "level": "critical", "metric": "disk",
                "value": disk, "threshold": DISK_CRIT_THRESHOLD,
                "message": f"Disk critical: {disk:.1f}% used"
            })
            self._set_alerted("disk_crit")

        elif disk >= DISK_WARN_THRESHOLD and self._cooldown_ok("disk_warn"):
            anomalies.append({
                "level": "warning", "metric": "disk",
                "value": disk, "threshold": DISK_WARN_THRESHOLD,
                "message": f"Disk filling: {disk:.1f}% used"
            })
            self._set_alerted("disk_warn")

        return anomalies

    def get_trends(self) -> dict:
        return {
            "cpu_trend_per_min":  self._trend_rate(self.cpu_history),
            "mem_trend_per_min":  self._trend_rate(self.mem_history),
            "disk_trend_per_min": self._trend_rate(self.disk_history),
            "cpu_samples":  len(self.cpu_history),
            "mem_samples":  len(self.mem_history),
        }
