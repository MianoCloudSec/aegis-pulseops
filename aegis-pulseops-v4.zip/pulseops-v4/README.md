# Aegis-PulseOps
**Autonomous Cloud Resilience Platform**
*Huawei Cloud Infrastructure Challenge 2025*

---

## Overview

Aegis-PulseOps is a two-component cloud resilience platform:

- **Aegis** — Server Guardian Agent. Runs inside Linux servers, monitors health metrics, detects anomalies, and executes first-line recovery actions automatically.
- **PulseOps** — Central Control Platform. FastAPI backend with real-time WebSocket dashboard for operators to visualize health, receive alerts, send commands, and run chaos tests.

---

## Architecture

```
Operator Browser
      │
      ▼ (HTTP / WebSocket)
┌─────────────────────┐
│   PulseOps Backend  │  ← FastAPI + SQLite
│   port 8000         │
│   /api/*            │
│   /ws               │
│   static/index.html │
└──────────┬──────────┘
           │ (HTTP REST — agent polls every 5s)
           ▼
┌─────────────────────┐
│   Aegis Agent       │  ← Python daemon
│   Collects metrics  │
│   Detects anomalies │
│   Executes recovery │
│   Runs chaos tests  │
└──────────┬──────────┘
           │
           ▼
    Linux OS + Services
```

---

## Quick Start

```bash
# 1. Clone / copy to your ECS VM
cd aegis-pulseops

# 2. Run setup (installs deps, creates .env)
bash setup.sh

# 3. Start everything
bash run.sh

# 4. Open dashboard
http://<your-server-ip>:8000
```

---

## Manual Start (Two Terminals)

```bash
# Terminal 1 — PulseOps
python3 -m uvicorn pulseops.main:app --host 0.0.0.0 --port 8000 --reload

# Terminal 2 — Aegis
python3 -m aegis.agent
```

---

## Configuration (.env)

| Variable | Default | Description |
|----------|---------|-------------|
| `PULSEOPS_URL` | `http://127.0.0.1:8000` | PulseOps API URL |
| `AEGIS_NODE_ID` | `node-<hostname>` | Unique node identifier |
| `METRICS_INTERVAL` | `10` | Seconds between metric pushes |
| `CPU_WARN` | `75` | CPU warning threshold (%) |
| `CPU_CRIT` | `90` | CPU critical threshold (%) |
| `MEM_WARN` | `75` | Memory warning threshold (%) |
| `MEM_CRIT` | `90` | Memory critical threshold (%) |
| `DISK_WARN` | `80` | Disk warning threshold (%) |
| `AUTO_RECOVERY` | `true` | Enable automatic recovery |
| `RECOVERY_COOLDOWN` | `120` | Seconds between recovery attempts |
| `MONITORED_SERVICES` | `nginx,ssh,cron` | Services to monitor |

---

## API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/metrics` | Aegis pushes metrics |
| GET | `/api/nodes` | List all nodes |
| GET | `/api/metrics/{node_id}` | Get metric history |
| POST | `/api/alerts` | Aegis reports anomaly |
| GET | `/api/alerts` | List active alerts |
| POST | `/api/commands` | Send command to node |
| GET | `/api/commands/pending` | Aegis polls commands |
| POST | `/api/chaos/inject` | Inject fault scenario |
| POST | `/api/chaos/stop` | Stop chaos |
| GET | `/api/chaos/sessions` | Chaos history |
| GET | `/api/chaos/stats` | Aggregated MTTR stats |
| WS | `/ws` | Real-time dashboard feed |
| GET | `/docs` | Interactive API docs (Swagger) |

---

## Chaos Mode Scenarios

| Scenario | What it does | Recovery action |
|----------|-------------|-----------------|
| `cpu_spike` | Overloads CPU with stress workers | Kill runaway process |
| `memory_leak` | Allocates RAM gradually | Drop page cache |
| `disk_fill` | Writes temp files to fill disk | Clean logs + remove temp files |
| `service_kill` | Stops a monitored service | Restart service |

---

## Dashboard Tabs

- **Overview** — Live metrics, KPIs, AI reasoning panel, 4 charts
- **Chaos Mode** — Inject/stop scenarios, live session monitor
- **Chaos History** — MTTR trend chart, peak metrics chart, full sessions table
- **Alerts** — Active alert list with acknowledge buttons

---

## File Structure

```
aegis-pulseops/
├── pulseops/
│   ├── main.py          # FastAPI app + WebSocket
│   ├── database.py      # SQLite schema + init
│   ├── models.py        # Pydantic schemas
│   ├── api/
│   │   ├── metrics.py   # Metrics endpoints
│   │   ├── alerts.py    # Alert endpoints
│   │   ├── commands.py  # Command endpoints
│   │   └── chaos.py     # Chaos + recovery endpoints
│   └── static/
│       └── index.html   # Full dashboard UI
├── aegis/
│   ├── agent.py         # Main daemon loop
│   ├── collector.py     # psutil metric collection
│   ├── detector.py      # Anomaly detection (threshold + trend)
│   ├── recovery.py      # Auto-recovery actions
│   ├── chaos.py         # Fault injection engine
│   └── config.py        # Configuration
├── requirements.txt
├── setup.sh
├── run.sh
└── README.md
```

---

## Demo Script (Competition)

1. Start the system with `bash run.sh`
2. Open dashboard — watch Aegis agent appear in the node list
3. Go to **Chaos Mode** tab
4. Select the node, set intensity to 80%
5. Click **CPU Spike** — watch metrics climb in real time
6. Aegis detects the anomaly within ~20 seconds
7. Auto-recovery triggers — Aegis kills the runaway process
8. Metrics normalize — banner shows "Recovery Complete"
9. Go to **Chaos History** — MTTR recorded, chart updates
10. Repeat with Memory Leak and Disk Fill
11. Show judges the MTTR trend chart — improving over multiple runs
