#!/bin/bash
# ─────────────────────────────────────────────────────────────────
#  Aegis-PulseOps Setup Script
#  Installs dependencies and starts both PulseOps and Aegis
# ─────────────────────────────────────────────────────────────────

set -e
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${CYAN}"
echo "  ╔══════════════════════════════════════════╗"
echo "  ║       AEGIS-PULSEOPS SETUP v1.0          ║"
echo "  ║  Autonomous Cloud Resilience Platform    ║"
echo "  ╚══════════════════════════════════════════╝"
echo -e "${NC}"

# ── Check Python ──────────────────────────────────────────────────
if ! command -v python3 &>/dev/null; then
    echo -e "${RED}Python3 not found. Install with: sudo apt install python3 python3-pip${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Python3 found: $(python3 --version)${NC}"

# ── Install dependencies ──────────────────────────────────────────
echo -e "${YELLOW}→ Installing Python dependencies...${NC}"
pip3 install -r requirements.txt --quiet

# ── Install stress-ng (for chaos CPU tests) ───────────────────────
if ! command -v stress-ng &>/dev/null; then
    echo -e "${YELLOW}→ Installing stress-ng for chaos testing...${NC}"
    sudo apt-get install -y stress-ng 2>/dev/null || \
    sudo yum install -y stress-ng 2>/dev/null || \
    echo -e "${YELLOW}⚠ stress-ng not installed — chaos will use Python fallback${NC}"
else
    echo -e "${GREEN}✓ stress-ng available${NC}"
fi

# ── Create .env if not exists ─────────────────────────────────────
if [ ! -f .env ]; then
cat > .env << EOF
# PulseOps configuration
PULSEOPS_URL=http://127.0.0.1:8000

# Aegis node identity
AEGIS_NODE_ID=node-$(hostname)

# Monitoring intervals (seconds)
METRICS_INTERVAL=10
CMD_POLL_INTERVAL=5

# Thresholds
CPU_WARN=75
CPU_CRIT=90
MEM_WARN=75
MEM_CRIT=90
DISK_WARN=80
DISK_CRIT=90

# Auto-recovery
AUTO_RECOVERY=true
RECOVERY_COOLDOWN=120

# Services to monitor (comma separated)
MONITORED_SERVICES=nginx,ssh,cron
EOF
echo -e "${GREEN}✓ Created .env configuration${NC}"
fi

echo -e "${GREEN}✓ Setup complete${NC}"
echo ""
echo -e "${CYAN}To start the full system:${NC}"
echo ""
echo -e "  ${YELLOW}# Terminal 1 — Start PulseOps backend + dashboard${NC}"
echo -e "  python3 -m uvicorn pulseops.main:app --host 0.0.0.0 --port 8000 --reload"
echo ""
echo -e "  ${YELLOW}# Terminal 2 — Start Aegis agent${NC}"
echo -e "  python3 -m aegis.agent"
echo ""
echo -e "  ${YELLOW}# Or use the run script:${NC}"
echo -e "  bash run.sh"
echo ""
echo -e "${CYAN}Dashboard: http://$(hostname -I | awk '{print $1}'):8000${NC}"
echo ""
