#!/bin/bash
# ─────────────────────────────────────────────────────────────────
#  Aegis-PulseOps Run Script
#  Starts PulseOps backend and Aegis agent together
# ─────────────────────────────────────────────────────────────────

# Load env
if [ -f .env ]; then
    export $(cat .env | grep -v '#' | xargs)
fi

# Kill on exit
cleanup() {
    echo ""
    echo "Stopping Aegis-PulseOps..."
    kill $PULSEOPS_PID $AEGIS_PID 2>/dev/null
    exit 0
}
trap cleanup SIGINT SIGTERM

echo "Starting PulseOps backend..."
python3 -m uvicorn pulseops.main:app --host 0.0.0.0 --port 8000 &
PULSEOPS_PID=$!

echo "Waiting for PulseOps to start..."
sleep 3

echo "Starting Aegis agent..."
python3 -m aegis.agent &
AEGIS_PID=$!

echo ""
echo "═══════════════════════════════════════════"
echo "  Aegis-PulseOps running"
echo "  Dashboard: http://0.0.0.0:8000"
echo "  Press Ctrl+C to stop"
echo "═══════════════════════════════════════════"

wait
