import os, socket, uuid

# ── Identity ──────────────────────────────────────────────────────────────
NODE_ID   = os.environ.get("AEGIS_NODE_ID", f"node-{socket.gethostname()}")
HOSTNAME  = socket.gethostname()
IP_ADDRESS = os.environ.get("AEGIS_IP", None)

# ── PulseOps connection ───────────────────────────────────────────────────
PULSEOPS_URL = os.environ.get("PULSEOPS_URL", "http://127.0.0.1:8000")

# ── Collection intervals ──────────────────────────────────────────────────
METRICS_INTERVAL   = int(os.environ.get("METRICS_INTERVAL", "10"))    # seconds
COMMAND_POLL_INTERVAL = int(os.environ.get("CMD_POLL_INTERVAL", "5")) # seconds

# ── Anomaly detection thresholds ─────────────────────────────────────────
CPU_WARN_THRESHOLD     = float(os.environ.get("CPU_WARN",  "75"))
CPU_CRIT_THRESHOLD     = float(os.environ.get("CPU_CRIT",  "90"))
MEM_WARN_THRESHOLD     = float(os.environ.get("MEM_WARN",  "75"))
MEM_CRIT_THRESHOLD     = float(os.environ.get("MEM_CRIT",  "90"))
DISK_WARN_THRESHOLD    = float(os.environ.get("DISK_WARN", "80"))
DISK_CRIT_THRESHOLD    = float(os.environ.get("DISK_CRIT", "90"))

# ── Trend detection ───────────────────────────────────────────────────────
TREND_WINDOW_MINUTES   = int(os.environ.get("TREND_WINDOW", "10"))
TREND_RATE_THRESHOLD   = float(os.environ.get("TREND_RATE", "1.5"))  # %/min triggers alert

# ── Recovery ─────────────────────────────────────────────────────────────
AUTO_RECOVERY_ENABLED  = os.environ.get("AUTO_RECOVERY", "true").lower() == "true"
RECOVERY_COOLDOWN      = int(os.environ.get("RECOVERY_COOLDOWN", "120"))  # seconds

# ── Services to monitor ───────────────────────────────────────────────────
MONITORED_SERVICES = os.environ.get(
    "MONITORED_SERVICES", "nginx,ssh,cron"
).split(",")
