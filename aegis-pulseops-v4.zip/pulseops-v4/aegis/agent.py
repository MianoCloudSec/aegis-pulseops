#!/usr/bin/env python3
"""
Aegis — Server Guardian Agent
Runs on each Linux server, reports to PulseOps.
Fast polling mode activates automatically during chaos injection.
"""
import time
import logging
import json
import sys
import httpx

from aegis.config import (
    NODE_ID, PULSEOPS_URL,
    METRICS_INTERVAL, COMMAND_POLL_INTERVAL,
    AUTO_RECOVERY_ENABLED
)
from aegis.collector  import collect_metrics, collect_service_status
from aegis.detector   import AnomalyDetector
from aegis.recovery   import RecoveryEngine
from aegis.chaos      import ChaosEngine

# ── Logging ───────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)-8s %(name)s — %(message)s",
    datefmt="%H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("/tmp/aegis.log"),
    ]
)
logger = logging.getLogger("aegis")

# ── Globals ───────────────────────────────────────────────────────────────
detector = AnomalyDetector()
recovery = RecoveryEngine()
chaos    = ChaosEngine()
client   = httpx.Client(base_url=PULSEOPS_URL, timeout=10.0)

# Chaos session tracking
_chaos_start_time: dict[str, float] = {}
_chaos_detected:   dict[str, bool]  = {}

# Fast poll mode: 3s interval when chaos is active, normal otherwise
FAST_INTERVAL   = 3   # seconds during chaos
NORMAL_INTERVAL = METRICS_INTERVAL


def post_metrics(metrics: dict):
    try:
        r = client.post("/api/metrics", json=metrics)
        r.raise_for_status()
    except Exception as e:
        logger.warning(f"Failed to post metrics: {e}")


def post_alert(anomaly: dict) -> int | None:
    try:
        payload = {
            "node_id":   NODE_ID,
            "level":     anomaly["level"],
            "metric":    anomaly["metric"],
            "value":     anomaly["value"],
            "threshold": anomaly["threshold"],
            "message":   anomaly["message"],
        }
        r = client.post("/api/alerts", json=payload)
        r.raise_for_status()
        return r.json().get("alert_id")
    except Exception as e:
        logger.warning(f"Failed to post alert: {e}")
        return None


def post_recovery(report: dict, alert_id=None, chaos_id=None):
    try:
        payload = {
            "node_id":     NODE_ID,
            "alert_id":    alert_id,
            "chaos_id":    chaos_id,
            "action_type": report["action_type"],
            "target":      report.get("target"),
            "success":     report["success"],
            "duration_ms": report["duration_ms"],
            "output":      report.get("output"),
        }
        client.post("/api/recovery", json=payload)
    except Exception as e:
        logger.warning(f"Failed to post recovery: {e}")


def complete_chaos_session(session_id: int, recovery_action: str,
                            success: bool, detect_time: float, recover_time: float):
    try:
        client.post("/api/chaos/complete", params={
            "session_id":       session_id,
            "node_id":          NODE_ID,
            "recovery_action":  recovery_action,
            "recovery_success": success,
            "time_to_detect":   detect_time,
            "time_to_recover":  recover_time,
        })
    except Exception as e:
        logger.warning(f"Failed to complete chaos session: {e}")


def poll_and_execute_commands():
    try:
        r = client.get("/api/commands/pending", params={"node_id": NODE_ID})
        r.raise_for_status()
        commands = r.json()
    except Exception as e:
        logger.warning(f"Failed to poll commands: {e}")
        return

    for cmd in commands:
        cmd_id   = cmd["id"]
        command  = cmd["command"]
        args_str = cmd.get("args") or ""

        logger.info(f"Executing command: {command} args={args_str}")
        result_status = "completed"
        result_output = ""

        try:
            if command == "chaos_inject":
                parts      = args_str.split(":")
                scenario   = parts[0]
                intensity  = int(parts[1]) if len(parts) > 1 else 50
                duration   = int(parts[2]) if len(parts) > 2 else 0
                session_id = int(parts[3]) if len(parts) > 3 and parts[3] else None

                res = chaos.inject(scenario, intensity, duration, session_id)
                _chaos_start_time[scenario] = time.time()
                _chaos_detected[scenario]   = False
                result_output = json.dumps(res)
                logger.info(f"[Chaos] Injected {scenario} at {intensity}% — FAST POLL MODE ON (3s)")

            elif command == "chaos_stop":
                res = chaos.stop()
                result_output = json.dumps(res)
                logger.info("[Chaos] Stopped — returning to normal poll interval")

            elif command == "restart_service":
                res = recovery.restart_service(args_str)
                result_output = res.get("output", "")
                if not res["success"]:
                    result_status = "failed"

            elif command == "kill_process":
                import psutil
                pid = int(args_str)
                p = psutil.Process(pid)
                p.kill()
                result_output = f"Killed PID {pid}"

            else:
                result_output = f"Unknown command: {command}"
                result_status = "failed"

        except Exception as e:
            result_status = "failed"
            result_output = str(e)
            logger.error(f"Command {command} failed: {e}")

        try:
            client.post("/api/commands/result", json={
                "command_id": cmd_id,
                "node_id":    NODE_ID,
                "status":     result_status,
                "result":     result_output,
            })
        except Exception as e:
            logger.warning(f"Failed to report command result: {e}")


def metrics_loop():
    logger.info(f"[Aegis] Node ID: {NODE_ID}")
    logger.info(f"[Aegis] Reporting to: {PULSEOPS_URL}")
    logger.info(f"[Aegis] Auto-recovery: {AUTO_RECOVERY_ENABLED}")
    logger.info(f"[Aegis] Normal interval: {NORMAL_INTERVAL}s | Chaos interval: {FAST_INTERVAL}s")

    last_command_poll = 0

    while True:
        loop_start = time.time()

        # ── Determine interval (fast during chaos) ────────────────────────
        is_chaos_active = len(chaos.active_scenarios()) > 0
        interval = FAST_INTERVAL if is_chaos_active else NORMAL_INTERVAL

        # ── Collect ───────────────────────────────────────────────────────
        metrics = collect_metrics()
        post_metrics(metrics)
        logger.info(f"CPU={metrics['cpu_percent']:.1f}% "
                    f"MEM={metrics['mem_percent']:.1f}% "
                    f"DISK={metrics['disk_percent']:.1f}% "
                    f"[{'CHAOS' if is_chaos_active else 'normal'}]")

        # ── Detect anomalies ──────────────────────────────────────────────
        anomalies = detector.analyze(metrics)

        for anomaly in anomalies:
            logger.warning(f"ANOMALY: {anomaly['message']}")
            alert_id = post_alert(anomaly)

            # Track detection time for active chaos sessions
            for scenario in chaos.active_scenarios():
                if not _chaos_detected.get(scenario):
                    _chaos_detected[scenario] = True
                    start = _chaos_start_time.get(scenario, loop_start)
                    detect_seconds = loop_start - start
                    logger.info(f"[Chaos] Detected {scenario} in {detect_seconds:.1f}s")

            # ── Recover ───────────────────────────────────────────────────
            if AUTO_RECOVERY_ENABLED:
                report = recovery.respond(anomaly)
                if report:
                    logger.info(f"RECOVERY: {report['action_type']} → "
                                f"{'OK' if report['success'] else 'FAILED'} "
                                f"({report['duration_ms']:.0f}ms)")
                    post_recovery(report, alert_id=alert_id)

                    for scenario in chaos.active_scenarios():
                        session_id = chaos._session_ids.get(scenario)
                        if session_id:
                            start        = _chaos_start_time.get(scenario, loop_start)
                            detect_time  = loop_start - start
                            recover_time = report["duration_ms"] / 1000
                            complete_chaos_session(
                                session_id,
                                report["action_type"],
                                report["success"],
                                detect_time,
                                recover_time
                            )

        # ── Poll commands ─────────────────────────────────────────────────
        now = time.time()
        # Always poll commands fast when chaos is active
        cmd_interval = 3 if is_chaos_active else COMMAND_POLL_INTERVAL
        if now - last_command_poll >= cmd_interval:
            poll_and_execute_commands()
            last_command_poll = now

        # ── Sleep ─────────────────────────────────────────────────────────
        elapsed    = time.time() - loop_start
        sleep_time = max(0, interval - elapsed)
        time.sleep(sleep_time)


def main():
    logger.info("=" * 50)
    logger.info("  AEGIS — Server Guardian Agent  ")
    logger.info("  Aegis-PulseOps Platform v1.0   ")
    logger.info("=" * 50)

    for attempt in range(10):
        try:
            r = client.get("/health")
            if r.status_code == 200:
                logger.info(f"[Aegis] Connected to PulseOps at {PULSEOPS_URL}")
                break
        except Exception:
            pass
        logger.info(f"[Aegis] Waiting for PulseOps... ({attempt+1}/10)")
        time.sleep(3)

    metrics_loop()


if __name__ == "__main__":
    main()
