import subprocess
import threading
import time
import os
import logging
import tempfile

logger = logging.getLogger("aegis.chaos")

class ChaosEngine:
    def __init__(self):
        self._active_processes: dict[str, subprocess.Popen] = {}
        self._active_threads:   dict[str, threading.Thread] = {}
        self._stop_events:      dict[str, threading.Event]  = {}
        self._session_ids:      dict[str, int]              = {}
        self._start_times:      dict[str, float]            = {}
        self._temp_files:       list[str]                   = []

    def is_active(self, scenario: str = None) -> bool:
        if scenario:
            return scenario in self._active_processes or scenario in self._active_threads
        return bool(self._active_processes or self._active_threads)

    def active_scenarios(self) -> list:
        return list(set(list(self._active_processes.keys()) + list(self._active_threads.keys())))

    # ── Inject ────────────────────────────────────────────────────────────
    def inject(self, scenario_type: str, intensity: int = 50,
               duration: int = 0, session_id: int = None) -> dict:
        """
        Start a chaos scenario.
        intensity: 1-100
        duration: 0 = run until stop() called
        """
        if self.is_active(scenario_type):
            return {"success": False, "message": f"{scenario_type} already running"}

        self._session_ids[scenario_type] = session_id
        self._start_times[scenario_type] = time.time()

        if scenario_type == "cpu_spike":
            result = self._inject_cpu(intensity, duration)
        elif scenario_type == "memory_leak":
            result = self._inject_memory(intensity, duration)
        elif scenario_type == "disk_fill":
            result = self._inject_disk(intensity, duration)
        elif scenario_type == "service_kill":
            result = self._inject_service_kill(intensity)
        else:
            return {"success": False, "message": f"Unknown scenario: {scenario_type}"}

        logger.info(f"[Chaos] Injected {scenario_type} intensity={intensity}: {result}")
        return result

    # ── Stop ──────────────────────────────────────────────────────────────
    def stop(self, scenario_type: str = None) -> dict:
        """Stop one or all active chaos scenarios."""
        stopped = []

        targets = [scenario_type] if scenario_type else self.active_scenarios()

        for scenario in targets:
            # Stop subprocess
            if scenario in self._active_processes:
                try:
                    proc = self._active_processes.pop(scenario)
                    proc.terminate()
                    proc.wait(timeout=5)
                    stopped.append(scenario)
                except Exception as e:
                    logger.warning(f"[Chaos] Error stopping {scenario}: {e}")
                    try:
                        proc.kill()
                    except Exception:
                        pass

            # Stop thread
            if scenario in self._stop_events:
                self._stop_events[scenario].set()
                if scenario in self._active_threads:
                    self._active_threads[scenario].join(timeout=5)
                    self._active_threads.pop(scenario, None)
                self._stop_events.pop(scenario, None)
                stopped.append(scenario)

        # Clean up temp files
        for f in self._temp_files[:]:
            try:
                os.remove(f)
                self._temp_files.remove(f)
            except Exception:
                pass

        return {"success": True, "stopped": stopped}

    # ── CPU spike ─────────────────────────────────────────────────────────
    def _inject_cpu(self, intensity: int, duration: int) -> dict:
        # Use stress-ng if available, else pure Python spinners
        cpu_count = os.cpu_count() or 1
        workers   = max(1, int(cpu_count * intensity / 100))

        try:
            args = ["stress-ng", "--cpu", str(workers), "--cpu-load", str(intensity)]
            if duration > 0:
                args += ["--timeout", str(duration)]
            proc = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self._active_processes["cpu_spike"] = proc
            return {"success": True, "method": "stress-ng", "workers": workers}
        except FileNotFoundError:
            pass

        # Fallback: Python spinners
        stop_event = threading.Event()
        self._stop_events["cpu_spike"] = stop_event

        def spinner():
            end = time.time() + duration if duration > 0 else float("inf")
            while not stop_event.is_set() and time.time() < end:
                # Burn CPU proportional to intensity
                busy_end = time.time() + (intensity / 100) * 0.1
                while time.time() < busy_end:
                    _ = sum(i * i for i in range(1000))
                time.sleep(0.1 * (1 - intensity / 100))

        threads = []
        for _ in range(workers):
            t = threading.Thread(target=spinner, daemon=True)
            t.start()
            threads.append(t)

        self._active_threads["cpu_spike"] = threads[0]
        return {"success": True, "method": "python_spinner", "workers": workers}

    # ── Memory leak ───────────────────────────────────────────────────────
    def _inject_memory(self, intensity: int, duration: int) -> dict:
        import psutil
        total_mem = psutil.virtual_memory().total
        target_bytes = int(total_mem * intensity / 100)
        chunk_size   = 10 * 1024 * 1024  # 10MB chunks

        stop_event = threading.Event()
        self._stop_events["memory_leak"] = stop_event

        def leaker():
            allocated = []
            end = time.time() + duration if duration > 0 else float("inf")
            try:
                while not stop_event.is_set() and time.time() < end:
                    total_allocated = sum(len(b) for b in allocated)
                    if total_allocated < target_bytes:
                        allocated.append(bytearray(chunk_size))
                        time.sleep(0.2)
                    else:
                        time.sleep(1)
                # Hold until stopped
                while not stop_event.is_set():
                    time.sleep(0.5)
            finally:
                del allocated

        t = threading.Thread(target=leaker, daemon=True)
        t.start()
        self._active_threads["memory_leak"] = t
        return {"success": True, "target_mb": target_bytes // (1024*1024)}

    # ── Disk fill ─────────────────────────────────────────────────────────
    def _inject_disk(self, intensity: int, duration: int) -> dict:
        import psutil
        disk_info = psutil.disk_usage("/")
        free_bytes = disk_info.free
        target_bytes = int(free_bytes * intensity / 100)
        target_bytes = min(target_bytes, 512 * 1024 * 1024)  # cap at 512MB

        stop_event = threading.Event()
        self._stop_events["disk_fill"] = stop_event

        tmp = tempfile.mktemp(prefix="aegis_chaos_", suffix=".tmp")
        self._temp_files.append(tmp)

        def filler():
            try:
                with open(tmp, "wb") as f:
                    written = 0
                    chunk = b"\x00" * (1024 * 1024)  # 1MB
                    while not stop_event.is_set() and written < target_bytes:
                        f.write(chunk)
                        f.flush()
                        written += len(chunk)
                        time.sleep(0.05)
                end = time.time() + duration if duration > 0 else float("inf")
                while not stop_event.is_set() and time.time() < end:
                    time.sleep(1)
            finally:
                try:
                    os.remove(tmp)
                    if tmp in self._temp_files:
                        self._temp_files.remove(tmp)
                except Exception:
                    pass

        t = threading.Thread(target=filler, daemon=True)
        t.start()
        self._active_threads["disk_fill"] = t
        return {"success": True, "target_mb": target_bytes // (1024*1024)}

    # ── Service kill ──────────────────────────────────────────────────────
    def _inject_service_kill(self, intensity: int) -> dict:
        # Default: stop a non-critical demo service
        service = "cron"
        try:
            result = subprocess.run(
                ["systemctl", "stop", service],
                capture_output=True, text=True, timeout=10
            )
            success = result.returncode == 0
            # Mark as active so stop() can restart it
            stop_event = threading.Event()
            self._stop_events["service_kill"] = stop_event
            self._active_processes["service_kill"] = None  # sentinel
            return {"success": success, "service": service}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def stop_service_kill(self, service: str = "cron"):
        """Restart the killed service."""
        try:
            subprocess.run(["systemctl", "start", service],
                           capture_output=True, timeout=10)
        except Exception:
            pass
        self._active_processes.pop("service_kill", None)
        if "service_kill" in self._stop_events:
            self._stop_events["service_kill"].set()
            self._stop_events.pop("service_kill")
