import psutil
import time
import socket
from aegis.config import HOSTNAME, IP_ADDRESS, NODE_ID, MONITORED_SERVICES

def get_ip():
    if IP_ADDRESS:
        return IP_ADDRESS
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

def collect_metrics() -> dict:
    """Collect all system metrics and return as a dict."""
    cpu     = psutil.cpu_percent(interval=1)
    mem     = psutil.virtual_memory()
    disk    = psutil.disk_usage("/")
    net     = psutil.net_io_counters()
    load    = psutil.getloadavg()
    procs   = len(psutil.pids())

    return {
        "node_id":        NODE_ID,
        "hostname":       HOSTNAME,
        "ip_address":     get_ip(),
        "timestamp":      time.time(),
        "cpu_percent":    cpu,
        "mem_percent":    mem.percent,
        "disk_percent":   disk.percent,
        "net_bytes_sent": net.bytes_sent,
        "net_bytes_recv": net.bytes_recv,
        "load_avg_1":     load[0],
        "load_avg_5":     load[1],
        "load_avg_15":    load[2],
        "process_count":  procs,
    }

def collect_service_status() -> list:
    """Check status of monitored services."""
    results = []
    for svc in MONITORED_SERVICES:
        svc = svc.strip()
        if not svc:
            continue
        try:
            import subprocess
            result = subprocess.run(
                ["systemctl", "is-active", svc],
                capture_output=True, text=True, timeout=3
            )
            status = result.stdout.strip()
        except Exception:
            status = "unknown"
        results.append({"service": svc, "status": status})
    return results

def get_top_processes(n=5) -> list:
    """Return top N processes by CPU usage."""
    procs = []
    for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
        try:
            procs.append(p.info)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    return sorted(procs, key=lambda x: x.get("cpu_percent", 0), reverse=True)[:n]
