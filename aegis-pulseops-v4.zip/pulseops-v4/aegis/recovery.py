import subprocess
import time
import psutil
import logging
from aegis.config import NODE_ID, AUTO_RECOVERY_ENABLED, RECOVERY_COOLDOWN

logger = logging.getLogger("aegis.recovery")

class RecoveryEngine:
    def __init__(self):
        self._last_recovery = {}  # metric -> last recovery time

    def _cooldown_ok(self, key: str) -> bool:
        last = self._last_recovery.get(key, 0)
        return (time.time() - last) > RECOVERY_COOLDOWN

    def _set_recovered(self, key: str):
        self._last_recovery[key] = time.time()

    def respond(self, anomaly: dict) -> dict | None:
        """
        Given an anomaly dict, decide and execute a recovery action.
        Returns a recovery report dict or None if no action taken.
        """
        if not AUTO_RECOVERY_ENABLED:
            logger.info(f"[Recovery] Auto-recovery disabled — skipping {anomaly['metric']}")
            return None

        metric = anomaly["metric"]
        level  = anomaly["level"]
        value  = anomaly["value"]

        if not self._cooldown_ok(f"{metric}_{level}"):
            logger.info(f"[Recovery] Cooldown active for {metric} — skipping")
            return None

        logger.info(f"[Recovery] Responding to {level} {metric} at {value:.1f}%")

        if metric == "cpu":
            result = self._recover_cpu(value, level)
        elif metric == "memory":
            result = self._recover_memory(value, level)
        elif metric == "disk":
            result = self._recover_disk(value, level)
        else:
            return None

        if result:
            self._set_recovered(f"{metric}_{level}")

        return result

    # ── CPU Recovery ──────────────────────────────────────────────────────
    def _recover_cpu(self, value: float, level: str) -> dict:
        start = time.time()

        if level == "critical":
            # Find and kill the top CPU-consuming process (excluding critical system processes)
            action, target, output, success = self._kill_top_cpu_process()
        else:
            # Warning: try restarting the most suspicious service first
            action  = "log_alert"
            target  = "system"
            output  = f"CPU at {value:.1f}% — monitoring, no action at warning level"
            success = True

        return {
            "action_type":  action,
            "target":       target,
            "success":      success,
            "duration_ms":  (time.time() - start) * 1000,
            "output":       output,
        }

    def _kill_top_cpu_process(self):
        SAFE_PROCESSES = {
            "systemd", "init", "kernel", "kthreadd", "python3",
            "uvicorn", "sshd", "bash", "sh", "aegis"
        }
        try:
            top_proc = None
            top_cpu  = 0
            for p in psutil.process_iter(["pid", "name", "cpu_percent"]):
                try:
                    info = p.info
                    if info["name"] in SAFE_PROCESSES:
                        continue
                    if info["cpu_percent"] > top_cpu:
                        top_cpu  = info["cpu_percent"]
                        top_proc = p
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass

            if top_proc and top_cpu > 20:
                name = top_proc.name()
                pid  = top_proc.pid
                top_proc.kill()
                return (
                    "kill_process",
                    f"{name}[{pid}]",
                    f"Killed {name} (PID {pid}) using {top_cpu:.1f}% CPU",
                    True
                )
            else:
                return ("log_alert", "none", "No killable high-CPU process found", False)
        except Exception as e:
            return ("kill_process", "unknown", f"Error: {e}", False)

    # ── Memory Recovery ───────────────────────────────────────────────────
    def _recover_memory(self, value: float, level: str) -> dict:
        start = time.time()

        if level == "critical":
            # Drop page cache (safe on Linux)
            action, target, output, success = self._drop_caches()
        else:
            action  = "log_alert"
            target  = "system"
            output  = f"Memory at {value:.1f}% — monitoring"
            success = True

        return {
            "action_type":  action,
            "target":       target,
            "success":      success,
            "duration_ms":  (time.time() - start) * 1000,
            "output":       output,
        }

    def _drop_caches(self):
        try:
            result = subprocess.run(
                ["sh", "-c", "sync && echo 3 > /proc/sys/vm/drop_caches"],
                capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0:
                return ("drop_caches", "/proc/sys/vm/drop_caches",
                        "Page cache dropped successfully", True)
            else:
                return ("drop_caches", "/proc/sys/vm/drop_caches",
                        f"Failed: {result.stderr}", False)
        except Exception as e:
            return ("drop_caches", "system", f"Error: {e}", False)

    # ── Disk Recovery ─────────────────────────────────────────────────────
    def _recover_disk(self, value: float, level: str) -> dict:
        start = time.time()
        action, target, output, success = self._clean_logs()
        return {
            "action_type":  action,
            "target":       target,
            "success":      success,
            "duration_ms":  (time.time() - start) * 1000,
            "output":       output,
        }

    def _clean_logs(self):
        try:
            result = subprocess.run(
                ["journalctl", "--vacuum-size=100M"],
                capture_output=True, text=True, timeout=30
            )
            freed = result.stderr or result.stdout or "Done"
            return ("clean_logs", "/var/log", freed.strip(), result.returncode == 0)
        except Exception as e:
            return ("clean_logs", "/var/log", f"Error: {e}", False)

    # ── Service restart (called from command handler) ──────────────────────
    def restart_service(self, service_name: str) -> dict:
        start = time.time()
        try:
            result = subprocess.run(
                ["systemctl", "restart", service_name],
                capture_output=True, text=True, timeout=30
            )
            success = result.returncode == 0
            output  = result.stdout or result.stderr or "Done"
            return {
                "action_type": "restart_service",
                "target":      service_name,
                "success":     success,
                "duration_ms": (time.time() - start) * 1000,
                "output":      output.strip(),
            }
        except Exception as e:
            return {
                "action_type": "restart_service",
                "target":      service_name,
                "success":     False,
                "duration_ms": (time.time() - start) * 1000,
                "output":      str(e),
            }
