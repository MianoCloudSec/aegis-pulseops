import aiosqlite
import os

DB_PATH = os.environ.get("DB_PATH", "pulseops.db")

CREATE_TABLES = """
CREATE TABLE IF NOT EXISTS nodes (
    id          TEXT PRIMARY KEY,
    hostname    TEXT NOT NULL,
    ip_address  TEXT,
    status      TEXT DEFAULT 'unknown',
    last_seen   REAL,
    registered_at REAL
);

CREATE TABLE IF NOT EXISTS metrics (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    node_id     TEXT NOT NULL,
    timestamp   REAL NOT NULL,
    cpu_percent REAL,
    mem_percent REAL,
    disk_percent REAL,
    net_bytes_sent REAL,
    net_bytes_recv REAL,
    load_avg_1  REAL,
    load_avg_5  REAL,
    load_avg_15 REAL,
    process_count INTEGER,
    FOREIGN KEY (node_id) REFERENCES nodes(id)
);

CREATE TABLE IF NOT EXISTS alerts (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    node_id         TEXT NOT NULL,
    timestamp       REAL NOT NULL,
    level           TEXT NOT NULL,
    metric          TEXT NOT NULL,
    value           REAL,
    threshold       REAL,
    message         TEXT,
    acknowledged    INTEGER DEFAULT 0,
    resolved        INTEGER DEFAULT 0,
    resolved_at     REAL,
    FOREIGN KEY (node_id) REFERENCES nodes(id)
);

CREATE TABLE IF NOT EXISTS commands (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    node_id     TEXT NOT NULL,
    command     TEXT NOT NULL,
    args        TEXT,
    status      TEXT DEFAULT 'pending',
    created_at  REAL NOT NULL,
    executed_at REAL,
    result      TEXT,
    FOREIGN KEY (node_id) REFERENCES nodes(id)
);

CREATE TABLE IF NOT EXISTS chaos_sessions (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    node_id             TEXT NOT NULL,
    scenario_type       TEXT NOT NULL,
    triggered_by        TEXT DEFAULT 'operator',
    started_at          REAL NOT NULL,
    stopped_at          REAL,
    duration_seconds    REAL,
    intensity           INTEGER DEFAULT 50,
    peak_cpu            REAL,
    peak_memory         REAL,
    peak_disk           REAL,
    baseline_cpu        REAL,
    baseline_memory     REAL,
    time_to_detect      REAL,
    time_to_recover     REAL,
    recovery_action     TEXT,
    recovery_success    INTEGER DEFAULT 0,
    status              TEXT DEFAULT 'running',
    notes               TEXT,
    FOREIGN KEY (node_id) REFERENCES nodes(id)
);

CREATE TABLE IF NOT EXISTS recovery_actions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    node_id         TEXT NOT NULL,
    alert_id        INTEGER,
    chaos_id        INTEGER,
    timestamp       REAL NOT NULL,
    action_type     TEXT NOT NULL,
    target          TEXT,
    success         INTEGER DEFAULT 0,
    duration_ms     REAL,
    output          TEXT,
    FOREIGN KEY (node_id) REFERENCES nodes(id)
);

CREATE INDEX IF NOT EXISTS idx_metrics_node_time ON metrics(node_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_alerts_node ON alerts(node_id);
CREATE INDEX IF NOT EXISTS idx_chaos_node ON chaos_sessions(node_id);
"""

async def get_db():
    db = await aiosqlite.connect(DB_PATH)
    db.row_factory = aiosqlite.Row
    return db

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.executescript(CREATE_TABLES)
        await db.commit()
    print(f"[PulseOps] Database initialized at {DB_PATH}")
