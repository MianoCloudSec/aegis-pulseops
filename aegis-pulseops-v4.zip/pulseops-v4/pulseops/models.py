from pydantic import BaseModel
from typing import Optional, List
import time

class MetricPayload(BaseModel):
    node_id: str
    hostname: str
    ip_address: Optional[str] = None
    timestamp: Optional[float] = None
    cpu_percent: float
    mem_percent: float
    disk_percent: float
    net_bytes_sent: float = 0
    net_bytes_recv: float = 0
    load_avg_1: float = 0
    load_avg_5: float = 0
    load_avg_15: float = 0
    process_count: int = 0

class AlertPayload(BaseModel):
    node_id: str
    level: str           # info / warning / critical
    metric: str          # cpu / memory / disk / service
    value: float
    threshold: float
    message: str
    timestamp: Optional[float] = None

class CommandCreate(BaseModel):
    node_id: str
    command: str         # restart_service / kill_process / run_gc / stop_chaos
    args: Optional[str] = None

class CommandResult(BaseModel):
    command_id: int
    node_id: str
    status: str          # completed / failed
    result: Optional[str] = None

class ChaosInject(BaseModel):
    node_id: str
    scenario_type: str   # cpu_spike / memory_leak / disk_fill / service_kill
    intensity: int = 50  # 1-100
    duration_seconds: Optional[int] = None
    triggered_by: str = "operator"

class ChaosStop(BaseModel):
    node_id: str
    session_id: Optional[int] = None

class RecoveryReport(BaseModel):
    node_id: str
    chaos_id: Optional[int] = None
    alert_id: Optional[int] = None
    action_type: str
    target: Optional[str] = None
    success: bool
    duration_ms: float
    output: Optional[str] = None
