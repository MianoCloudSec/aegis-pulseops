from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from contextlib import asynccontextmanager
import asyncio, json, time, os

from pulseops.database import init_db, get_db
from pulseops.api import metrics, alerts, commands, chaos

# ── WebSocket connection manager ──────────────────────────────────────────
class ConnectionManager:
    def __init__(self):
        self.active: list[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.active.append(ws)

    def disconnect(self, ws: WebSocket):
        if ws in self.active:
            self.active.remove(ws)

    async def broadcast(self, data: dict):
        dead = []
        for ws in self.active:
            try:
                await ws.send_json(data)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws)

manager = ConnectionManager()

# ── Background broadcaster ────────────────────────────────────────────────
async def broadcast_loop():
    """Push latest node metrics to all dashboard clients every 5 seconds."""
    while True:
        await asyncio.sleep(5)
        if not manager.active:
            continue
        try:
            db = await get_db()
            try:
                # Latest metric per node
                async with db.execute("""
                    SELECT m.*, n.hostname, n.status as node_status
                    FROM metrics m
                    JOIN nodes n ON m.node_id = n.id
                    WHERE m.id IN (
                        SELECT MAX(id) FROM metrics GROUP BY node_id
                    )
                """) as cur:
                    rows = await cur.fetchall()

                # Active alerts count
                async with db.execute(
                    "SELECT COUNT(*) as cnt FROM alerts WHERE resolved=0"
                ) as cur:
                    alert_row = await cur.fetchone()

                # Active chaos sessions
                async with db.execute(
                    "SELECT * FROM chaos_sessions WHERE status='running'"
                ) as cur:
                    chaos_rows = await cur.fetchall()

            finally:
                await db.close()

            await manager.broadcast({
                "type": "metrics_update",
                "timestamp": time.time(),
                "nodes": [dict(r) for r in rows],
                "active_alerts": alert_row["cnt"] if alert_row else 0,
                "active_chaos": [dict(r) for r in chaos_rows],
            })
        except Exception as e:
            print(f"[Broadcast] Error: {e}")

# ── App lifecycle ──────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    task = asyncio.create_task(broadcast_loop())
    print("[PulseOps] Server started — http://0.0.0.0:8000")
    yield
    task.cancel()

app = FastAPI(
    title="Aegis-PulseOps API",
    description="Autonomous Cloud Resilience Platform",
    version="1.0.0",
    lifespan=lifespan
)

# ── Routers ───────────────────────────────────────────────────────────────
app.include_router(metrics.router, prefix="/api", tags=["Metrics"])
app.include_router(alerts.router,  prefix="/api", tags=["Alerts"])
app.include_router(commands.router,prefix="/api", tags=["Commands"])
app.include_router(chaos.router,   prefix="/api", tags=["Chaos"])

# ── WebSocket ─────────────────────────────────────────────────────────────
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        # Send initial state on connect
        db = await get_db()
        try:
            async with db.execute("SELECT * FROM nodes") as cur:
                nodes = await cur.fetchall()
            async with db.execute(
                "SELECT * FROM alerts WHERE resolved=0 ORDER BY timestamp DESC LIMIT 20"
            ) as cur:
                active_alerts = await cur.fetchall()
        finally:
            await db.close()

        await websocket.send_json({
            "type": "initial_state",
            "nodes": [dict(n) for n in nodes],
            "active_alerts": [dict(a) for a in active_alerts],
        })

        while True:
            # Keep connection alive, handle incoming messages
            data = await websocket.receive_text()
            msg = json.loads(data)
            if msg.get("type") == "ping":
                await websocket.send_json({"type": "pong"})

    except WebSocketDisconnect:
        manager.disconnect(websocket)

# ── Static frontend ───────────────────────────────────────────────────────
static_dir = os.path.join(os.path.dirname(__file__), "static")
if os.path.exists(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")

@app.get("/")
async def serve_dashboard():
    index = os.path.join(static_dir, "index.html")
    if os.path.exists(index):
        return FileResponse(index)
    return {"message": "Aegis-PulseOps API running", "docs": "/docs"}

@app.get("/health")
async def health():
    return {"status": "ok", "time": time.time()}
