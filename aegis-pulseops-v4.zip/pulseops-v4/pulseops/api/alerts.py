from fastapi import APIRouter
from pulseops.database import get_db
from pulseops.models import AlertPayload
import time

router = APIRouter()

@router.post("/alerts")
async def post_alert(payload: AlertPayload):
    ts = payload.timestamp or time.time()
    db = await get_db()
    try:
        async with db.execute("""
            INSERT INTO alerts (node_id, timestamp, level, metric, value, threshold, message)
            VALUES (?,?,?,?,?,?,?)
        """, (payload.node_id, ts, payload.level, payload.metric,
              payload.value, payload.threshold, payload.message)) as cur:
            alert_id = cur.lastrowid
        await db.commit()
    finally:
        await db.close()
    return {"status": "ok", "alert_id": alert_id}


@router.get("/alerts")
async def get_alerts(node_id: str = None, resolved: bool = False, limit: int = 100):
    db = await get_db()
    try:
        if node_id:
            async with db.execute("""
                SELECT * FROM alerts WHERE node_id=? AND resolved=?
                ORDER BY timestamp DESC LIMIT ?
            """, (node_id, int(resolved), limit)) as cur:
                rows = await cur.fetchall()
        else:
            async with db.execute("""
                SELECT * FROM alerts WHERE resolved=?
                ORDER BY timestamp DESC LIMIT ?
            """, (int(resolved), limit)) as cur:
                rows = await cur.fetchall()
    finally:
        await db.close()
    return [dict(r) for r in rows]


@router.post("/alerts/{alert_id}/acknowledge")
async def acknowledge_alert(alert_id: int):
    db = await get_db()
    try:
        await db.execute("UPDATE alerts SET acknowledged=1 WHERE id=?", (alert_id,))
        await db.commit()
    finally:
        await db.close()
    return {"status": "ok"}


@router.post("/alerts/{alert_id}/resolve")
async def resolve_alert(alert_id: int):
    db = await get_db()
    try:
        await db.execute("""
            UPDATE alerts SET resolved=1, resolved_at=? WHERE id=?
        """, (time.time(), alert_id))
        await db.commit()
    finally:
        await db.close()
    return {"status": "ok"}
