from fastapi import APIRouter
from pulseops.database import get_db
from pulseops.models import CommandCreate, CommandResult
import time

router = APIRouter()

@router.post("/commands")
async def create_command(payload: CommandCreate):
    db = await get_db()
    try:
        async with db.execute("""
            INSERT INTO commands (node_id, command, args, status, created_at)
            VALUES (?,?,?,?,?)
        """, (payload.node_id, payload.command, payload.args, 'pending', time.time())) as cur:
            cmd_id = cur.lastrowid
        await db.commit()
    finally:
        await db.close()
    return {"status": "ok", "command_id": cmd_id}


@router.get("/commands/pending")
async def get_pending_commands(node_id: str):
    db = await get_db()
    try:
        async with db.execute("""
            SELECT * FROM commands
            WHERE node_id=? AND status='pending'
            ORDER BY created_at ASC
        """, (node_id,)) as cur:
            rows = await cur.fetchall()
    finally:
        await db.close()
    return [dict(r) for r in rows]


@router.post("/commands/result")
async def submit_command_result(payload: CommandResult):
    db = await get_db()
    try:
        await db.execute("""
            UPDATE commands SET status=?, result=?, executed_at=?
            WHERE id=?
        """, (payload.status, payload.result, time.time(), payload.command_id))
        await db.commit()
    finally:
        await db.close()
    return {"status": "ok"}


@router.get("/commands/{node_id}/history")
async def get_command_history(node_id: str, limit: int = 50):
    db = await get_db()
    try:
        async with db.execute("""
            SELECT * FROM commands WHERE node_id=?
            ORDER BY created_at DESC LIMIT ?
        """, (node_id, limit)) as cur:
            rows = await cur.fetchall()
    finally:
        await db.close()
    return [dict(r) for r in rows]
