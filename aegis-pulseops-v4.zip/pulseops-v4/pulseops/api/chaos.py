from fastapi import APIRouter, HTTPException
from pulseops.database import get_db
from pulseops.models import ChaosInject, ChaosStop, RecoveryReport
import time

router = APIRouter()

@router.post("/chaos/inject")
async def inject_chaos(payload: ChaosInject):
    db = await get_db()
    try:
        # Get baseline metrics (last reading)
        async with db.execute("""
            SELECT cpu_percent, mem_percent FROM metrics
            WHERE node_id=? ORDER BY timestamp DESC LIMIT 1
        """, (payload.node_id,)) as cur:
            baseline = await cur.fetchone()

        baseline_cpu = baseline["cpu_percent"] if baseline else 0
        baseline_mem = baseline["mem_percent"] if baseline else 0

        async with db.execute("""
            INSERT INTO chaos_sessions
            (node_id, scenario_type, triggered_by, started_at, intensity,
             baseline_cpu, baseline_memory, status)
            VALUES (?,?,?,?,?,?,?,'running')
        """, (payload.node_id, payload.scenario_type, payload.triggered_by,
              time.time(), payload.intensity, baseline_cpu, baseline_mem)) as cur:
            session_id = cur.lastrowid

        # Queue chaos command for the agent
        await db.execute("""
            INSERT INTO commands (node_id, command, args, status, created_at)
            VALUES (?, 'chaos_inject', ?, 'pending', ?)
        """, (payload.node_id,
              f"{payload.scenario_type}:{payload.intensity}:{payload.duration_seconds or 0}:{session_id}",
              time.time()))

        await db.commit()
    finally:
        await db.close()

    return {"status": "ok", "session_id": session_id}


@router.post("/chaos/stop")
async def stop_chaos(payload: ChaosStop):
    db = await get_db()
    try:
        if payload.session_id:
            await db.execute("""
                UPDATE chaos_sessions SET status='stopping'
                WHERE id=? AND node_id=?
            """, (payload.session_id, payload.node_id))
        else:
            await db.execute("""
                UPDATE chaos_sessions SET status='stopping'
                WHERE node_id=? AND status='running'
            """, (payload.node_id,))

        # Queue stop command
        await db.execute("""
            INSERT INTO commands (node_id, command, args, status, created_at)
            VALUES (?, 'chaos_stop', ?, 'pending', ?)
        """, (payload.node_id, str(payload.session_id or ''), time.time()))

        await db.commit()
    finally:
        await db.close()
    return {"status": "ok"}


@router.post("/chaos/complete")
async def complete_chaos(session_id: int, node_id: str,
                         recovery_action: str = None, recovery_success: bool = False,
                         time_to_detect: float = None, time_to_recover: float = None):
    db = await get_db()
    try:
        now = time.time()
        async with db.execute(
            "SELECT started_at FROM chaos_sessions WHERE id=?", (session_id,)
        ) as cur:
            row = await cur.fetchone()

        duration = (now - row["started_at"]) if row else 0

        await db.execute("""
            UPDATE chaos_sessions SET
                stopped_at=?, duration_seconds=?, status='completed',
                recovery_action=?, recovery_success=?,
                time_to_detect=?, time_to_recover=?
            WHERE id=?
        """, (now, duration, recovery_action, int(recovery_success),
              time_to_detect, time_to_recover, session_id))
        await db.commit()
    finally:
        await db.close()
    return {"status": "ok"}


@router.get("/chaos/sessions")
async def get_chaos_sessions(node_id: str = None, limit: int = 50):
    db = await get_db()
    try:
        if node_id:
            async with db.execute("""
                SELECT * FROM chaos_sessions WHERE node_id=?
                ORDER BY started_at DESC LIMIT ?
            """, (node_id, limit)) as cur:
                rows = await cur.fetchall()
        else:
            async with db.execute("""
                SELECT * FROM chaos_sessions
                ORDER BY started_at DESC LIMIT ?
            """, (limit,)) as cur:
                rows = await cur.fetchall()
    finally:
        await db.close()
    return [dict(r) for r in rows]


@router.get("/chaos/sessions/{session_id}")
async def get_chaos_session(session_id: int):
    db = await get_db()
    try:
        async with db.execute(
            "SELECT * FROM chaos_sessions WHERE id=?", (session_id,)
        ) as cur:
            row = await cur.fetchone()
    finally:
        await db.close()
    if not row:
        raise HTTPException(status_code=404, detail="Session not found")
    return dict(row)


@router.get("/chaos/stats")
async def get_chaos_stats(node_id: str = None):
    """Aggregate stats across all chaos tests — for the MTTR trend chart."""
    db = await get_db()
    try:
        filter_clause = "WHERE node_id=?" if node_id else "WHERE 1=1"
        params = (node_id,) if node_id else ()

        async with db.execute(f"""
            SELECT
                COUNT(*) as total_tests,
                SUM(CASE WHEN recovery_success=1 THEN 1 ELSE 0 END) as successful_recoveries,
                AVG(time_to_detect) as avg_detect_seconds,
                AVG(time_to_recover) as avg_mttr_seconds,
                MIN(time_to_recover) as best_mttr,
                MAX(time_to_recover) as worst_mttr,
                AVG(peak_cpu) as avg_peak_cpu,
                AVG(peak_memory) as avg_peak_memory,
                COUNT(DISTINCT scenario_type) as scenario_types_tested
            FROM chaos_sessions
            {filter_clause} AND status='completed'
        """, params) as cur:
            stats = await cur.fetchone()

        # Per-scenario breakdown
        async with db.execute(f"""
            SELECT scenario_type,
                   COUNT(*) as count,
                   AVG(time_to_detect) as avg_detect,
                   AVG(time_to_recover) as avg_recover,
                   SUM(CASE WHEN recovery_success=1 THEN 1 ELSE 0 END) as successes
            FROM chaos_sessions
            {filter_clause} AND status='completed'
            GROUP BY scenario_type
        """, params) as cur:
            by_scenario = await cur.fetchall()

        # MTTR over time (for trend chart)
        async with db.execute(f"""
            SELECT id, started_at, scenario_type,
                   time_to_detect, time_to_recover,
                   recovery_success, peak_cpu, peak_memory
            FROM chaos_sessions
            {filter_clause} AND status='completed'
            ORDER BY started_at ASC
        """, params) as cur:
            timeline = await cur.fetchall()

    finally:
        await db.close()

    return {
        "summary": dict(stats) if stats else {},
        "by_scenario": [dict(r) for r in by_scenario],
        "mttr_timeline": [dict(r) for r in timeline]
    }


@router.post("/recovery")
async def report_recovery(payload: RecoveryReport):
    db = await get_db()
    try:
        await db.execute("""
            INSERT INTO recovery_actions
            (node_id, alert_id, chaos_id, timestamp, action_type,
             target, success, duration_ms, output)
            VALUES (?,?,?,?,?,?,?,?,?)
        """, (payload.node_id, payload.alert_id, payload.chaos_id,
              time.time(), payload.action_type, payload.target,
              int(payload.success), payload.duration_ms, payload.output))
        await db.commit()
    finally:
        await db.close()
    return {"status": "ok"}


@router.get("/recovery/history")
async def get_recovery_history(node_id: str = None, limit: int = 100):
    db = await get_db()
    try:
        if node_id:
            async with db.execute("""
                SELECT * FROM recovery_actions WHERE node_id=?
                ORDER BY timestamp DESC LIMIT ?
            """, (node_id, limit)) as cur:
                rows = await cur.fetchall()
        else:
            async with db.execute("""
                SELECT * FROM recovery_actions
                ORDER BY timestamp DESC LIMIT ?
            """, (limit,)) as cur:
                rows = await cur.fetchall()
    finally:
        await db.close()
    return [dict(r) for r in rows]
