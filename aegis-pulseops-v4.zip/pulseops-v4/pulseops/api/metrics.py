from fastapi import APIRouter, HTTPException
from pulseops.database import get_db
from pulseops.models import MetricPayload
import time

router = APIRouter()

@router.post("/metrics")
async def post_metrics(payload: MetricPayload):
    ts = payload.timestamp or time.time()
    db = await get_db()
    try:
        # Upsert node
        await db.execute("""
            INSERT INTO nodes (id, hostname, ip_address, status, last_seen, registered_at)
            VALUES (?, ?, ?, 'online', ?, COALESCE((SELECT registered_at FROM nodes WHERE id=?), ?))
            ON CONFLICT(id) DO UPDATE SET
                hostname=excluded.hostname,
                ip_address=excluded.ip_address,
                status='online',
                last_seen=excluded.last_seen
        """, (payload.node_id, payload.hostname, payload.ip_address, ts, payload.node_id, ts))

        # Insert metrics
        await db.execute("""
            INSERT INTO metrics
            (node_id, timestamp, cpu_percent, mem_percent, disk_percent,
             net_bytes_sent, net_bytes_recv, load_avg_1, load_avg_5, load_avg_15, process_count)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)
        """, (payload.node_id, ts, payload.cpu_percent, payload.mem_percent,
              payload.disk_percent, payload.net_bytes_sent, payload.net_bytes_recv,
              payload.load_avg_1, payload.load_avg_5, payload.load_avg_15, payload.process_count))

        await db.commit()

        # Update active chaos session peaks
        await db.execute("""
            UPDATE chaos_sessions SET
                peak_cpu    = MAX(COALESCE(peak_cpu, 0),    ?),
                peak_memory = MAX(COALESCE(peak_memory, 0), ?),
                peak_disk   = MAX(COALESCE(peak_disk, 0),   ?)
            WHERE node_id=? AND status='running'
        """, (payload.cpu_percent, payload.mem_percent, payload.disk_percent, payload.node_id))
        await db.commit()

    finally:
        await db.close()

    return {"status": "ok", "timestamp": ts}


@router.get("/metrics/{node_id}")
async def get_metrics(node_id: str, limit: int = 120):
    db = await get_db()
    try:
        async with db.execute("""
            SELECT * FROM metrics WHERE node_id=?
            ORDER BY timestamp DESC LIMIT ?
        """, (node_id, limit)) as cur:
            rows = await cur.fetchall()
    finally:
        await db.close()

    rows = list(reversed(rows))
    return [dict(r) for r in rows]


@router.get("/nodes")
async def get_nodes():
    db = await get_db()
    try:
        # Mark nodes offline if not seen in 30s
        await db.execute("""
            UPDATE nodes SET status='offline'
            WHERE last_seen < ? AND status='online'
        """, (time.time() - 30,))
        await db.commit()

        async with db.execute("SELECT * FROM nodes ORDER BY id") as cur:
            rows = await cur.fetchall()
    finally:
        await db.close()
    return [dict(r) for r in rows]


@router.get("/nodes/{node_id}/summary")
async def get_node_summary(node_id: str):
    db = await get_db()
    try:
        async with db.execute("""
            SELECT * FROM metrics WHERE node_id=?
            ORDER BY timestamp DESC LIMIT 1
        """, (node_id,)) as cur:
            latest = await cur.fetchone()

        async with db.execute("""
            SELECT AVG(cpu_percent) as avg_cpu,
                   AVG(mem_percent) as avg_mem,
                   MAX(cpu_percent) as max_cpu,
                   MAX(mem_percent) as max_mem
            FROM metrics WHERE node_id=? AND timestamp > ?
        """, (node_id, time.time() - 3600)) as cur:
            stats = await cur.fetchone()
    finally:
        await db.close()

    return {
        "latest": dict(latest) if latest else None,
        "hourly_stats": dict(stats) if stats else None
    }
